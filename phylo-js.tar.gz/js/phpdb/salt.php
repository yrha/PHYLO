<?php
$salt = "!+@)#($^&hAS2DA!";
?>
