(function() {
	$(document).ready(function() {
		var doc = document;
		var div = doc.createElement("div");
		div.id = "reportBug";
		doc.appendChild(div);
	});
})();
